import { Component, OnInit, Input } from '@angular/core';
import * as d3 from 'd3';
import { interval } from 'rxjs';

@Component({
  selector: 'app-chartss',
  templateUrl: './chartss.component.html',
  styleUrls: ['./chartss.component.css']
})
export class ChartssComponent implements OnInit {
  @Input() progress: number = 75;

  private svg: any;
  private width: number = 200;
  private height: number = 200;
  private margin: number = 20;
  private radius: number = Math.min(this.width, this.height) / 2 - this.margin;
  private arc: any;
  private backgroundArc: any;
  private foreground: any;
  private currentProgress: number = 0;

  constructor() {}

  ngOnInit(): void {
    this.createSvg();
    this.createArcs();
    this.drawBackground();
    this.drawForeground();
    this.animateProgressCount();
  }

  private createSvg(): void {
    this.svg = d3.select('#circular-progress-bar')
      .append('svg')
      .attr('width', this.width)
      .attr('height', this.height)
      .append('g')
      .attr('transform', `translate(${this.width / 2},${this.height / 2})`);
  }

  private createArcs(): void {
     // Adjust inner radius to increase thickness
  const thickness = 18;
  this.arc = d3.arc()
    .innerRadius(this.radius - thickness)
    .outerRadius(this.radius)
    .startAngle(0);

  this.backgroundArc = d3.arc()
    .innerRadius(this.radius - thickness)
    .outerRadius(this.radius)
    .startAngle(0)
    .endAngle(2 * Math.PI);
  }

  private drawBackground(): void {
    this.svg.append('path')
      .attr('class', 'background')
      .attr('d', this.backgroundArc)
      .attr('fill', '#e6e6e6');
  }

  private drawForeground(): void {
    this.foreground = this.svg.append('path')
      .attr('class', 'foreground')
      .attr('fill', '#F7634F')
      .attr('d', this.arc.endAngle(this.currentProgress / 100 * 2 * Math.PI));
  
    // Text for percentage
    this.svg.append('text')
      .attr('text-anchor', 'middle')
      .attr('font-size', '30px')
      .attr('font-family','sans-serif')
      .attr('fill', 'black')
      .attr('dy', '.3em')
      .text(`${this.currentProgress}`)
      .attr('x', -2)
      .attr('y', -15);
  
    // Text for "Overall risk"
    this.svg.append('text')
      .attr('text-anchor', 'middle')
      .attr('font-size', '20px') // Adjust font size if needed
      .attr('fill', 'black')
      .attr('font-family','sans-serif')
      .attr('dy', '1.5em') // Move it slightly below the percentage text
      .text('Overall risk')
      .attr('x', 0)
      .attr('y', -5); // Adjust the y-coordinate to position it below the percentage text
  }
  

  private animateProgressCount(): void {
    const duration = 1000;
    interval(duration / this.progress).subscribe(() => {
      if (this.currentProgress < this.progress) {
        this.currentProgress++;
        this.foreground.attr('d', this.arc.endAngle(this.currentProgress / 100 * 2 * Math.PI));
        this.svg.select('text').text(`${this.currentProgress}`);
      }
    });
  }
}
