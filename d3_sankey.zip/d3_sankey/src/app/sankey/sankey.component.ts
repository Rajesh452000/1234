import { Component, OnInit, Input } from '@angular/core';
import * as d3 from 'd3';
import { sankey, SankeyGraph, SankeyNode, SankeyLink } from 'd3-sankey';

interface SankeyNodeMinimal {
  name: string;

}

interface SankeyLinkMinimal {
  source: number;
  target: number;
  value: number;
  percentage: number;
}

@Component({
  selector: 'app-sankey',
  templateUrl: './sankey.component.html',
  styleUrls: ['./sankey.component.css']
})
export class SankeyComponent implements OnInit {
  @Input() nodeWidth: number = 50;
  @Input() nodeHeightPadding: number = 20;
  @Input() width: number = 700;
  @Input() height: number = 500;
  @Input() rectWidth: number = 50;
  @Input() rectHeight: number = 20;
  @Input() firstNodeWidth: number = 200; // Custom width for the first node
  @Input() firstNodeHeight: number = 100; // Custom height for the first node

  private data: SankeyGraph<SankeyNodeMinimal, SankeyLinkMinimal> = {
    nodes: [
      { name: "Source A"  }, // Example progress value for Source A
      { name: "Alternative 1 (best)"  }, // Example progress value for node 1
      { name: "Alternative 2 (next best)" }, // Example progress value for node 2
      { name: "Alternative 3 " }, // Example progress value for node 3
      { name: "MWI - Pelham" }, // Example progress value for node 1a
      { name: "MWI - Elm Creek" }, // Example progress value for node 1b
      { name: "MWI - Scott City" }, // Example progress value for node new
      { name: "MWI - Nampa, ID" }, // Example progress value for node 3b
    ],
    links: [
      { source: 0, target: 1, value: 80, percentage: 17 },
      { source: 0, target: 2, value: 80, percentage: 43 },
      { source: 0, target: 3, value: 80, percentage: 27 },
      { source: 1, target: 4, value: 80, percentage: 23 },
      { source: 1, target: 5, value: 80, percentage: 15 },
      { source: 1, target: 6, value: 80, percentage: 31 },
      { source: 2, target: 6, value: 80, percentage: 25 },
      { source: 3, target: 6, value: 80, percentage: 35 },
      { source: 3, target: 7, value: 80, percentage: 20 },
    ]
  };
  progressData: number[] = [20, 40, 60, 80, 100]; // Progress values in percentage
  constructor() { }

  ngOnInit(): void {
    this.createSankeyChart();
  }

  private createSankeyChart(): void {
    const element = d3.select('#sankey-chart');
    const margin = { top: 10, right: 10, bottom: 10, left: 10 };
    const width = this.width - margin.left - margin.right;
    const height = this.height - margin.top - margin.bottom;
  
    const svg = element.append('svg')
      .attr('width', width + margin.left + margin.right+500)
      .attr('height', height + margin.top + margin.bottom+500)
      .append('g')
      .attr('transform', 'translate(150,30)');
  
    const sankeyGenerator = sankey<SankeyNodeMinimal, SankeyLinkMinimal>()
      .nodeWidth(this.nodeWidth)
      .nodePadding(this.nodeHeightPadding)
      .extent([[0, 50], [width -1, height - 6]]);
  
    const { nodes, links } = sankeyGenerator(this.data);
   // Define a color mapping for the nodes

// Define a color mapping for the nodes
const link = svg.append('g')
  .attr('class', 'links')
  .attr('fill', 'none')
  .attr('stroke-opacity', 0.5)
  .selectAll('path')
  .data(links)
  .enter().append('path')
  .attr('id', (d, i) => `link-${i}`) // Add id attribute for each link
  .attr('d', (d) => this.customLinkGenerator(d, nodes))
  .attr('stroke-width', (d) => this.calculateLinkWidth(d.percentage))
  .attr('stroke', 'url(#flowlinkGradient)')
  .attr('stroke-dasharray', function () {
    length = this.getTotalLength();
    return length + " " + length;
  })
  .attr('stroke-dashoffset', function () {
    return this.getTotalLength();
  })
  .transition()
  .delay(1000)
  .duration(1500) // Set the duration of the animation in milliseconds
  .ease(d3.easeLinear) // Set the easing function for the animation
  .attr('stroke-dashoffset', 0); // Animate the stroke-dashoffset to 0


// Append <title> elements to links
// link.append('title')
//     .text((d: any) => `${d.source.name} → ${d.target.name}\n${d.value} (${d.percentage}%)`);


  
  
  // Append text for displaying percentages
 // Append text for displaying percentages within the links
// Append text for displaying percentages within the links
// Append text for displaying percentages within the links
svg.append('g')
  .attr('class', 'percentage-labels')
  .selectAll('text')
  .data(links)
  .enter()
  .append('text')
  .attr('dy', '0.35em')
  .attr('text-anchor', 'middle')
  .append('textPath')
  .attr('startOffset', '50%')
  .attr('opacity', '0')
  .attr('xlink:href', (d, i) => `#link-${i}`)
  .text(d => '0%') // Start the animation from 0%
  .attr('fill', '#323273') // Adjust color as needed
  .attr('font-weight', 'bold')
  .attr('font-size', '12px')
  .transition() // Apply transition for smooth animation
  .delay(1000)
  .duration(1700) // Transition duration in milliseconds
  .attr('opacity', '100')
  .textTween(function (d) {
    var i = d3.interpolate(0, d.percentage); // Interpolate from 0 to the target percentage
    return function (t) {
      const sourceNode = d.source as SankeyNode<SankeyNodeMinimal, SankeyLinkMinimal>;
      if (sourceNode.index === 0) {
        return Math.round(i(t)) + '%'; // Add % symbol if the source node is the first node
      } else {
        return Math.round(i(t)).toString(); // Otherwise, return an empty string
      }
    };
  });





  
    const node = svg.append('g')
      .attr('class', 'nodes')
      .selectAll('g')
      .data(nodes)
      .enter().append('g');
  // Define the drop shadow filter
// Define the drop shadow filter
const defs = svg.append("defs");

const filter = defs.append("filter")
    .attr("id", "drop-shadow")
    .attr("x", "-50%")  // Increase the filter region to avoid clipping
    .attr("y", "-50%")
    .attr("width", "200%")
    .attr("height", "200%");

filter.append("feGaussianBlur")
    .attr("in", "SourceAlpha")
    .attr("stdDeviation", 3)  // Adjust blur radius
    .attr("result", "blur");

filter.append("feOffset")
    .attr("in", "blur")
    .attr("dx", 0)  // Horizontal offset
    .attr("dy", 5)  // Vertical offset (only downwards)
    .attr("result", "offsetBlur");

filter.append("feFlood")
    .attr("in", "offsetBlur")
    .attr("flood-color", "#F3F1F8")
    .attr("result", "colorBlur");

filter.append("feComposite")
    .attr("in", "colorBlur")
    .attr("in2", "offsetBlur")
    .attr("operator", "in")
    .attr("result", "colorBlur");

const feMerge = filter.append("feMerge");

feMerge.append("feMergeNode")
    .attr("in", "colorBlur");
feMerge.append("feMergeNode")
    .attr("in", "SourceGraphic");
    node.append('rect')
    .attr('x', (d: any, i: number) => i === 0 ? d.x0 - (this.firstNodeWidth - (d.x1 - d.x0)) / 2 : (this.isSourceNode(d, links) ? 315 : d.x0))
    .attr('y', (d: any, i: number) => i === 0 ? d.y0 - (this.firstNodeHeight - (d.y1 - d.y0)) / 2 : (this.isSourceNode(d, links) ? d.y0 - (this.firstNodeHeight - (d.y1 - d.y0) -20) / 2 : d.y0 ))
    .attr('height', (d: any, i: number) => i === 0 ? this.firstNodeHeight : (this.isSourceNode(d, links) ? 80 : d.y1 - d.y0 ))
    .attr('width',0)
    .attr('fill', (d: any, i: number) => i === 0 ? 'white': this.isSourceNode(d, links) ? 'url(#textGradient)' : 'url(#textGradient)')
    .attr('stroke',(d: any, i: number) => i === 0 ? '#EEF0FA': this.isSourceNode(d, links) ? 'none' : 'none')
    .attr('stroke-width','1px')
    .attr('rx', 10) // Horizontal radius of the rounded corners
    .attr('ry', 10) // Vertical radius of the rounded corners
    .style('filter', (d: any, i: number) => i === 0 ? 'url(#drop-shadow)' : null) // Apply drop shadow to the first node
    .transition() // Add transition for width
    .duration(800) // Set transition duration in milliseconds
    .attr('width', (d: any, i: number) => i === 0 ? this.firstNodeWidth : (this.isSourceNode(d, links) ? 180 : (this.isTargetNode(d, links) ? 120 : d.x1 - d.x0)))

    const gradient = svg.append("defs")
    .append("linearGradient")
    .attr("id", "textGradient")
    .attr("x1", "100%")
    .attr("y1", "0%")
    .attr("x2", "0%")
    .attr("y2", "100%");
  
  gradient.append("stop")
    .attr("offset", "0%")
    .attr("stop-color", "#3D3C7A"); // Start color
  
  gradient.append("stop")
    .attr("offset", "100%")
    .attr("stop-color", "#7F66C9"); // End color

    const gradient2 = svg.append("defs")
    .append("linearGradient")
    .attr("id", "flowlinkGradient")
    .attr("x1", "0%")
    .attr("y1", "0%")
    .attr("x2", "100%")
    .attr("y2", "100%");
  
  gradient2.append("stop")
    .attr("offset", "0%")
    .attr("stop-color", "#E2DBF8"); // Start color
  
  gradient2.append("stop")
    .attr("offset", "100%")
    .attr("stop-color", "#BAABE5"); // End color
  
    node.append('text')
    .attr('x', (d: any, i: number) => i === 0 ? 0: this.isSourceNode(d, links) ? d.x0 - (this.firstNodeWidth - (d.x1 - d.x0)) / 2 + this.firstNodeWidth / 2 -(10): d.x0 + (d.x1 - d.x0) / 2-(20)) //
      .attr('y', (d: any, i: number) => i === 0 || this.isSourceNode(d, links) ? d.y0 - (this.firstNodeHeight - (d.y1 - d.y0)) / 2 + this.firstNodeHeight / 2 -(23) : (d.y0 + d.y1) / 2)
      .attr('dy', '0.35em')
      .attr('text-anchor', 'start')
      .attr('font-size','13px')
      .text((d: any) => d.name)
      .attr('fill', (d: any, i: number) => i === 0 ? '#323273': this.isSourceNode(d, links) ? 'white' : 'white');

      node.filter((d: any, i: number) => i === 0) // Filter to select only the first node
      .append('text')
      .attr('x', (d: any) => d.x0 + (this.firstNodeWidth / 2)-80) // Center text horizontally
      .attr('y', (d: any) => d.y0 +25) // Position text above the first node
      .attr('dy', '0.35em')
      .attr('text-anchor', 'middle')
      .attr('font-size','14px')
      .attr('font-weight','bold')
      .attr('fill', '#383874') // Adjust color as needed
      .style('opacity', 0)
      .text('Switch Manufacturer') // Text content
      .transition() // Add transition for fade-in effect
      .duration(1000) // Duration of the fade-in effect in milliseconds
      .style('opacity', 1); // Transition to opacity 1

      svg.append('text')
      .attr('x', 200) // Center text horizontally
      .attr('y', 50) // Position text above the first node
      .attr('dy', '0.35em')
      .attr('text-anchor', 'middle')
      .attr('font-size','14px')
      .attr('font-weight','bold')
      .style('opacity', 0)
      .attr('fill', '#383874') // Adjust color as needed
      .text('Market Share') // Text content
      .transition() // Add transition for fade-in effect
      .duration(1000) // Duration of the fade-in effect in milliseconds
      .style('opacity', 1); // Transition to opacity 1

      svg.append('text')
      .attr('x', 400) // Center text horizontally
      .attr('y', 50) // Position text above the first node
      .attr('dy', '0.35em')
      .attr('text-anchor', 'middle')
      .attr('font-size','14px')
      .attr('font-weight','bold')
      .style('opacity', 0)
      .attr('fill', '#383874') // Adjust color as needed
      .text('Potential Substitutes') // Text content
      .transition() // Add transition for fade-in effect
      .duration(1000) // Duration of the fade-in effect in milliseconds
      .style('opacity', 1); // Transition to opacity 1

      svg.append('text')
      .attr('x', 550) // Center text horizontally
      .attr('y', 50) // Position text above the first node
      .attr('dy', '0.35em')
      .attr('text-anchor', 'middle')
      .attr('font-size','14px')
      .attr('font-weight','bold')
      .style('opacity', 0)
      .attr('fill', '#383874') // Adjust color as needed
      .text('Days on hand') // Text content
      .transition() // Add transition for fade-in effect
      .duration(1000) // Duration of the fade-in effect in milliseconds
      .style('opacity', 1); // Transition to opacity 1

      svg.append('text')
      .attr('x', 680) // Center text horizontally
      .attr('y', 30) // Position text above the first node
      .attr('dy', '0.35em')
      .attr('text-anchor', 'middle')
      .attr('font-size','14px')
      .attr('font-weight','bold')
      .style('opacity', 0)
      .attr('fill', '#383874') // Adjust color as needed
      .text('MWI DCs')  // Text content
      .transition() // Add transition for fade-in effect
      .duration(1000) // Duration of the fade-in effect in milliseconds
      .style('opacity', 1); // Transition to opacity 1


    var iconWidth =50;
    var iconHeight =50;
    node.filter((d: any, i: number) => i === 0)
    .append('image')
    .attr('xlink:href', './assets/Icon.svg')
    .attr('x', -60) // Adjust x position for the center of the node
    .attr('y', 200) // Adjust y position above the node text
    .attr('width', iconWidth)
    .attr('height', iconHeight);
// Add progress bar for source nodes
node.filter((d: any) => this.isSourceNode(d, links))
    .append('g') // Group element for the battery progress bar
    .attr('class', 'battery-bar')
    .attr('transform', (d: any,i:any) => `translate(${i === 0 ? d.x0 - 80 - (this.firstNodeWidth - (d.x1 - d.x0)) / 2 + this.firstNodeWidth / 2 : (this.isSourceNode(d, links) ? d.x0 - (this.firstNodeWidth - (d.x1 - d.x0)) / 2 + this.firstNodeWidth / 2 : d.x0 + (d.x1 - d.x0) / 2)}, ${i === 0 || this.isSourceNode(d, links) ? d.y0 - (this.firstNodeHeight - (d.y1 - d.y0) - 30) / 2 + this.firstNodeHeight / 2 : (d.y0 + d.y1) / 2})`)
    .each(function(d: any, i: number) {
        // Append battery background
        var batteryGroup = d3.select(this);

        // Append background rectangle
        batteryGroup.append('rect')
            .attr('x', -1.5) // Adjust x position for background rectangle
            .attr('y', -1.5) // Adjust y position for background rectangle
            .attr('width', 0) // Width of background rectangle
            .attr('height', 13) // Height of background rectangle
            .attr('fill', 'white') // Fill color for background rectangle
            .transition()
            .duration(1000)
            .attr('width', 115) 
        // Calculate total width for the battery bar
        var totalWidth = 5 * 30; // 5 rectangles each with width 30

        // Append five small rectangles horizontally
      // Append five small rectangles horizontally
for (var j = 0; j < 5; j++) {
  var isRed = j < 2;
  var batteryRect = batteryGroup.append('rect')
      .attr('x', j * 23) // Adjust x position for each rectangle
      .attr('y', 0) // Fixed y position
      .attr('width', isRed ? 0 : 20) // Initial width set to 0 for red, 20 for others
      .attr('height', 10) // Height of each rectangle
      .attr('fill', isRed ? '#00B4E6' : '#DBDFF1') // Fill color, red for first two, white for rest
      .attr('rx', 2) // Border radius for background rectangle
      .attr('ry', 2) // Border radius for background rectangle
      .attr('opacity','0')
      .transition()
      .delay(1000)
      .duration(1000)
      .attr('opacity','100')

  // Apply transition only to red rectangles
  if (isRed) {
      batteryRect.transition()
          .duration(1000) // Duration of the animation in milliseconds
          .delay(500 * j) // Delay each rectangle's animation
          .attr('width', 20); // Final width of each rectangle
  }
}

    });






  
    node.append('title')
      .text((d: any) => `${d.name}\n${d.value}`);
  
 
  }
  
  private isSourceNode(node: any, links: any[]): boolean {
    return links.some(link => link.source === node);
  }
  private isTargetNode(node: any, links: any[]): boolean {
    return links.some(link => link.target === node);
  }

  private customLinkGenerator(link: any, nodes: any) {
    const sourceNode = nodes[link.source.index];
    const targetNode = nodes[link.target.index];

    const sourceX = link.source.index === 0 ? sourceNode.x0 - (this.firstNodeWidth - (sourceNode.x1 - sourceNode.x0)) / 2 + this.firstNodeWidth : sourceNode.x1 +130;
    const sourceY = (sourceNode.y0 + sourceNode.y1) / 2;
    const targetX = link.target.index === 0 ? targetNode.x0 - (this.firstNodeWidth - (targetNode.x1 - targetNode.x0)) / 2 + this.firstNodeWidth : targetNode.x0 ;
    const targetY = (targetNode.y0 + targetNode.y1) / 2;

    const controlPointX = (sourceX + targetX) / 2;

    return `M${sourceX},${sourceY}
            C${controlPointX},${sourceY} ${controlPointX},${targetY} ${targetX},${targetY}`;
}


  private calculateLinkWidth(percentage: number): number {
    const maxWidth = 20; // Maximum stroke width
    return (percentage / 20) * maxWidth;
  }

}
