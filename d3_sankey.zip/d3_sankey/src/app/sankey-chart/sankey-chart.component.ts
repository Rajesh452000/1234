import { Component, OnInit } from '@angular/core';
import * as d3 from 'd3';
import { sankey as d3Sankey, sankeyLinkHorizontal, SankeyNodeMinimal, SankeyGraph } from 'd3-sankey';

interface CustomNode {
  node: number;
  name: string;
  progress: number;
  x0?: number;
  x1?: number;
  y0?: number;
  y1?: number;
  value?: number;
}

interface CustomLink {
  source: number;
  target: number;
  value: number;
  width?: number;
}

@Component({
  selector: 'app-sankey-chart',
  templateUrl: './sankey-chart.component.html',
  styleUrls: ['./sankey-chart.component.css']
})
export class SankeyChartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    this.drawChart();
  }

  drawChart() {
    /* DEFINE CHART SETTINGS *************************************************************/

    // Font Style
    var fontFamily = 'Comfortaa, cursive';
    var fontSize = 30;

    // SVG Size & Style
    const width = 500;
    const height = width;
    const margin = 70 * 2;
    const innerWidth = width - margin;
    const innerHeight = height - margin;
    var bgColor = 'None';

    // Line, Circle & Text Style
    var fill = 'white';
    const labelMargin = 4;
    const nodeWidth = 40;
    const nodePadding = 100;

    // Animation 
    var delay = 400;

    /* DEFINE DATA ************************************************************************/

    var data: { nodes: CustomNode[], links: CustomLink[] } = {
      "nodes": [
        { "node": 0, "name": "Alternative", "progress": 50 },
        { "node": 1, "name": "B", "progress": 70 },
        { "node": 2, "name": "C", "progress": 30 },
        { "node": 3, "name": "E", "progress": 90 },
        { "node": 4, "name": "F", "progress": 30 }
      ],
      "links": [
        { "source": 0, "target": 2, "value": 2 },
        { "source": 1, "target": 2, "value": 2 },
        { "source": 0, "target": 3, "value": 2 },
        { "source": 2, "target": 3, "value": 4 },
        { "source": 3, "target": 4, "value": 4 }
      ]
    };

    /* CREATE SVG  ************************************************************************/

    // Create SVG container
    var svg = d3.select('#sankey-chart')
      .append('svg')
      .attr("width", 1000)
      .attr("height", height)
      .style('background-color', bgColor);
      
    // Create container for the dots
    var sankeyGroup = svg.append("g")
      .attr("transform", `translate(350,${margin / 2})`);
   
    // Set the sankey chart properties
    var sankey = d3Sankey<CustomNode, CustomLink>()
      .nodeWidth(nodeWidth)
      .nodePadding(nodePadding)
      .extent([[1, 1], [innerWidth, innerHeight]]);

    const sankeyData: SankeyGraph<CustomNode, CustomLink> = sankey({
      nodes: data.nodes.map(d => Object.assign({}, d)),
      links: data.links.map(d => Object.assign({}, d))
    });

    // Create function for the axes transition
    var tweenDash = function (this: any) {
      const l = this.getTotalLength(),
        i = d3.interpolateString("0," + l, l + "," + l);
      return function (t:any) { return i(t) };
    };
    function customSankeyLink(d:any) {
      var curvature = 0.5;
      var x0 = d.source.x1 + (d.target.x0 - d.source.x1) * curvature;
      var x1 = d.target.x0 - (d.target.x0 - d.source.x1) * curvature;
      var y0 = d.source.y1;
      var y1 = d.target.y0;
      return `M${d.source.x1},${y0}C${x0},${y0} ${x1},${y1} ${d.target.x0},${y1}`;
    }
    

    // Add lines for each link
    var link = sankeyGroup.append("g")
      .selectAll(".link")
      .data(sankeyData.links)
      .enter()
      .append("path")
      .attr("class", "link")
      .attr("d", sankeyLinkHorizontal())
      .style("stroke-width", function (d, i) {
        if (i === 2 || i === 1) {
          return 43;
        } else if (i === 3 || i === 0) {
          return 70;
        } else {
          return Math.max(1, d.width || 1);
        }
      })
      .sort(function (a, b) { return (b.width || 0) - (a.width || 0); })
      .attr("fill", "None")
      .attr("stroke", "#4F4889")
      .attr("opacity", 0.3)
      .transition()
      .duration(delay * sankeyData.links.length)
      .attrTween("stroke-dasharray", tweenDash);

    // Create group elements for each node
    var node = sankeyGroup.append("g")
      .selectAll(".node")
      .data(sankeyData.nodes)
      .enter().append("g")
      .attr("class", "node")
      .attr("transform", function (d) { return "translate(" + d.x0 + "," + d.y0 + ")"; });

    // Add the cards for each node
    node
      .append("rect")
      .attr("height", function (d) { return d.y1! - d.y0!; })
      .attr("width", function (d, i) { return i === 0 ? 200 : nodeWidth; })
      .attr("transform", function (d, i) { return i === 0 ? "translate(-161,11)" : ""; })
      .style("fill", "#4F4889")
      .attr("rx", 6)
      .attr("ry", 6);

    // Add the title for each node inside the cards
    node
      .append("text")
      .attr("x", nodeWidth / 2)
      .attr("y", function (d) { return (d.y1! - d.y0!) / 2; })
      .attr("dy", "-0.5em")
      .attr("text-anchor", "middle")
      .attr("fill", "white")
      .attr("font-family", fontFamily)
      .attr("font-size", function (d, i) { return i === 0 ? 16 : fontSize; })
      .attr("transform", function (d, i) { return i === 0 ? "translate(-84,-46)" : ""; })
      .text(function (d) { return d.name; });

    // Add the progress bar inside the cards
    var progressBar = node
      .append("g")
      .attr("class", "progress-bar")
      .attr("transform", function (d, i) { return i === 0 ? "translate(-110,0)" : "translate(5,0)"; });

    // Add segmented blocks to progress bar
    for (let i = 0; i < 5; i++) {
      progressBar
        .append("rect")
        .attr("x", i * ((nodeWidth - 10) / 5))
        .attr("y", function (d) { return (d.y1! - d.y0!) / 2 - 10; })
        .attr("width", (nodeWidth) / 5 - 2)
        .attr("height", 20)
        .style("fill", function (d) { return d.progress >= (i + 1) * 20 ? "green" : "#DDDFEF"; })
        .style("stroke", "white");
    }

    // Add transition/ animation to the node titles
    node
      .attr('opacity', 0)
      .transition()
      .duration(delay)
      .attr('opacity', 1);
  }
}
