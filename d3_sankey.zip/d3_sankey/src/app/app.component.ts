import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'chart';
  progress: number = 0;

  increaseProgress(): void {
    this.progress = Math.min(100, this.progress + 10);
  }
}
